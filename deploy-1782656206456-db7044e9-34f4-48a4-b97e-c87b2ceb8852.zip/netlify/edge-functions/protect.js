/**
 * Edge function — protects all /api/* routes (except /api/unlock and /api/health).
 * Verifies the ht_session cookie using HMAC-SHA256.
 */
export default async (request, context) => {
  const url = new URL(request.url);

  // Unprotected endpoints
  if (url.pathname === '/api/unlock' || url.pathname === '/api/health') {
    return context.next();
  }

  // Only guard API routes
  if (!url.pathname.startsWith('/api/')) {
    return context.next();
  }

  const cookie = request.headers.get('cookie') || '';
  const match  = cookie.match(/ht_session=([^;]+)/);
  if (!match) return new Response('Unauthorized', { status: 401 });

  const secret   = Netlify.env.get('SESSION_SECRET') || 'change-me-in-netlify-env';
  const expected = await hmac(secret, 'authenticated');
  if (match[1] !== expected) return new Response('Unauthorized', { status: 401 });

  return context.next();
};

async function hmac(key, msg) {
  const enc = new TextEncoder();
  const k   = await crypto.subtle.importKey('raw', enc.encode(key), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig  = await crypto.subtle.sign('HMAC', k, enc.encode(msg));
  return btoa(String.fromCharCode(...new Uint8Array(sig)));
}

export const config = { path: '/api/*' };
