/**
 * POST /api/unlock  { pin: "1234" }
 * Validates PIN and sets a session cookie on success.
 * Set APP_PIN and SESSION_SECRET in Netlify env vars.
 */
export default async (req) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });

  let body;
  try { body = await req.json(); } catch { return new Response('Bad Request', { status: 400 }); }

  const correctPin = process.env.APP_PIN || '1234';
  if (body.pin !== correctPin) {
    return Response.json({ ok: false }, { status: 401 });
  }

  const secret = process.env.SESSION_SECRET || 'change-me-in-netlify-env';
  const token  = await hmac(secret, 'authenticated');
  const maxAge = 60 * 60 * 24; // 24 h

  return new Response(JSON.stringify({ ok: true }), {
    headers: {
      'Content-Type': 'application/json',
      'Set-Cookie':   `ht_session=${token}; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}; Path=/`,
    },
  });
};

async function hmac(key, msg) {
  const { createHmac } = await import('node:crypto');
  return createHmac('sha256', key).update(msg).digest('base64');
}

export const config = { path: '/api/unlock' };
