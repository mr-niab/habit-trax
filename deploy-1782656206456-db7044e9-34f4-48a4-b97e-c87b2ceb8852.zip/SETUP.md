# Habit Tracker — Setup Guide

## 1. Deploy to Netlify

1. Push this folder to a GitHub repo (or drag-and-drop to netlify.com/drop)
2. In Netlify: Site settings → Environment variables → Add the vars below

## 2. Environment Variables

| Variable | Value | Notes |
|---|---|---|
| `APP_PIN` | `1234` | Your passcode. Change to anything you like. |
| `SESSION_SECRET` | _(random string)_ | Used to sign auth cookies. Generate with `openssl rand -base64 32` |
| `ANTHROPIC_API_KEY` | `sk-ant-...` | For AI weekly reviews. Get at console.anthropic.com |
| `HEALTH_SECRET` | _(random string)_ | Shared secret for the Apple Shortcuts bridge |

## 3. Add to iPhone Home Screen

1. Open your Netlify URL in Safari on iPhone
2. Tap the Share button → **Add to Home Screen**
3. Name it "Habits" → Add
4. The app now opens full-screen with no browser chrome

## 4. Apple Shortcuts — Health Data Bridge

This lets the app show your real Apple Health activity data.

**Create the Shortcut:**
1. Open Shortcuts on iPhone
2. New Shortcut → add these actions in order:
   - **Get Health Samples** → Active Energy Burned → Today → sum
   - **Get Health Samples** → Steps → Today → sum  
   - **Get Health Samples** → Workout Minutes → Today → sum
   - **Get Contents of URL**:
     - URL: `https://YOUR-SITE.netlify.app/api/health`
     - Method: POST
     - Request Body: JSON
     - Fields:
       - `secret` = _(your HEALTH_SECRET value)_
       - `minutes` = Workout Minutes result
       - `steps` = Steps result
       - `kcal` = Active Energy result
3. **Automate** → New Automation → Time of Day → 9:00 PM → Run Shortcut

## 5. Changing Your Passcode

Update the `APP_PIN` environment variable in Netlify Site Settings → Environment Variables, then redeploy (trigger a deploy from the Deploys tab).

## 6. File Structure

```
├── index.html                    ← Full app (React via CDN, no build step)
├── manifest.json                 ← PWA manifest
├── netlify.toml                  ← Netlify config
├── package.json                  ← @netlify/blobs dependency
├── netlify/
│   ├── edge-functions/
│   │   └── protect.js           ← Auth gate (checks session cookie)
│   └── functions/
│       ├── unlock.js            ← PIN verification → sets cookie
│       ├── habits.js            ← GET/POST today's habit state
│       ├── log.js               ← Append meal/snack log entry
│       ├── health.js            ← Apple Shortcuts bridge
│       ├── weekly.js            ← 7-day data for weekly screen
│       └── weekly-review.js     ← Claude AI weekly insight
```

All habit data is stored in **Netlify Blobs** — private to your site, no third-party database needed.
